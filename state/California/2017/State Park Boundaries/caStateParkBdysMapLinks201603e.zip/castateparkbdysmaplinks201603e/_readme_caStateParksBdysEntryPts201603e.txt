California State Parks
Enterprise GIS Program

Park Boundaries, Entry Points, and Map Links - 2016.03

Download from http://www.parks.ca.gov/pages/862/files/caStateParkBdysMapLinks201603e.zip

Shapefiles representing Park Boundaries, SubUnits, and Entry Points, with hyperlinks to online maps.

ESRI Map Document and Layer Files from ArcMap 10.3.1.  

Google Earth rendition of Park Boundaries, SubUnits, and Entry Points included as KMZ file.

FGDC metadata included as xml and txt files.
==

See also File Geodatabase (GDB) format in separate download.

Monitor www.parks.ca.gov for the latest information about California State Parks.

Draft 2016.03e; geodata@parks.ca.gov